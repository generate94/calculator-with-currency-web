import toga
from toga.style import Pack
from toga.style.pack import COLUMN, ROW, RIGHT

class CurrencyConverterApp(toga.App):
    def startup(self):
        # Set initial base currency
        self.base_currency = "USD"
        
        # Main window
        self.main_window = toga.MainWindow(title=self.formal_name)

        # Input field
        self.input_field = toga.TextInput(style=Pack(flex=1, font_size=16))

        # Currency Label to Show Current Base Currency
        self.currency_label = toga.Label("(USD)", style=Pack(padding=(0, 10), font_size=10, text_align=RIGHT))
        
        # Currency Buttons
        usd_button = toga.Button("USD", on_press=lambda widget: self.convert_currency("USD"), style=Pack(flex=1))
        cad_button = toga.Button("CAD", on_press=lambda widget: self.convert_currency("CAD"), style=Pack(flex=1))
        peso_button = toga.Button("MXN", on_press=lambda widget: self.convert_currency("MXN"), style=Pack(flex=1))
        
        # Clear Button
        clear_button = toga.Button("C", on_press=self.clear_input, style=Pack(flex=1))

        # Calculator Buttons
        buttons = [
            ('7', '8', '9', '/'),
            ('4', '5', '6', '*'),
            ('1', '2', '3', '-'),
            ('0', '.', '=', '+')
        ]

        button_rows = []
        for button_row in buttons:
            row = []
            for button in button_row:
                row.append(toga.Button(button, on_press=lambda widget, b=button: self.on_button_click(b), style=Pack(flex=1)))
            button_rows.append(toga.Box(children=row, style=Pack(direction=ROW)))

        # Layout
        input_row = toga.Box(children=[self.input_field, self.currency_label], style=Pack(direction=ROW))
        currency_buttons_row = toga.Box(children=[usd_button, cad_button, peso_button, clear_button], style=Pack(direction=ROW))
        calculator_layout = toga.Box(children=button_rows, style=Pack(direction=COLUMN))

        # Main Box
        main_box = toga.Box(children=[input_row, currency_buttons_row, calculator_layout], style=Pack(direction=COLUMN, padding=10))

        self.main_window.content = main_box
        self.main_window.show()

        self.new_input = True  # Flag to clear old result on new input

    def convert_currency(self, new_currency):
        current_value = self.input_field.value.strip()
        
        if not current_value:
            # Only update base currency if input is empty
            self.base_currency = new_currency
            self.currency_label.text = f"({self.base_currency})"
            return

        # Try to convert the current input value to a number
        try:
            value_in_usd = float(current_value) / self.get_conversion_rate(self.base_currency)
            converted_value = value_in_usd * self.get_conversion_rate(new_currency)
            self.base_currency = new_currency
            self.input_field.value = f"{converted_value:.2f}"
            self.currency_label.text = f"({self.base_currency})"
            self.new_input = True  # Set flag to clear result on next input
        except ValueError:
            self.input_field.value = "Error"
    
    def clear_input(self, widget=None):
        self.input_field.value = ""

    def get_conversion_rate(self, currency):
        rates = self.get_exchange_rates()
        return rates.get(currency, 1)
        
    def get_exchange_rates(self):
        # Placeholder for actual API call
        return {"USD": 1, "CAD": 1.37, "MXN": 18.0}  # Fallback rates

    def on_button_click(self, value):
        if self.new_input:
            self.clear_input()
            self.new_input = False
        
        if value == "=":
            try:
                expression = self.input_field.value
                result = eval(expression)
                self.input_field.value = f"{result}"
                self.new_input = True  # Set flag to clear result on next input
            except:
                self.input_field.value = "Error"
        else:
            self.input_field.value += value

def main():
    return CurrencyConverterApp('Currency Converter', 'org.example.currencyconverter')

if __name__ == "__main__":
    main().main_loop()
